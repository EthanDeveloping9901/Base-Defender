import tkinter as tk
import math
import random
import os
import json

WIDTH, HEIGHT = 800, 600
BASE_RADIUS = 40
BASE_COLOR = "#ffcc99"
BASE_OUTLINE = "#cc9966"  # Darker shade for base outline
BASE_OUTLINE_WIDTH = 3
PLAYER_RADIUS = 18
PLAYER_COLOR = "#99ccff"
PLAYER_OUTLINE = "#6699cc"  # Darker blue outline for player
PLAYER_OUTLINE_WIDTH = 2
ORBIT_RADIUS = 70
BULLET_RADIUS = 8
BULLET_COLOR = "#cc99ff"
BULLET_OUTLINE = "#9966cc"  # Darker purple outline for bullets
BULLET_OUTLINE_WIDTH = 1.5
BULLET_SPEED = 10
BULLET_PADDING = 50
BULLET_DAMAGE = 20

# Special bullet settings
SPECIAL_BULLET_COLOR = "#ff9900"  # Orange color
SPECIAL_BULLET_OUTLINE = "#cc6600"  # Darker orange outline
SPECIAL_BULLET_DAMAGE = 40  # Double damage
SPECIAL_BULLET_COOLDOWN = 30000  # 30 seconds (in milliseconds)

# Powerup settings
POWERUP_RADIUS = 15
POWERUP_SPAWN_INTERVAL = 20000  # 20 seconds (in milliseconds)
POWERUP_DURATION = 15000  # 15 seconds (in milliseconds)
POWERUP_TYPES = [
    {"type": "Speed", "color": "#00ff00", "outline": "#008800", "effect": "Increases player bullet speed"},
    {"type": "Damage", "color": "#ff0000", "outline": "#880000", "effect": "Increases bullet damage"},
    {"type": "Shield", "color": "#0088ff", "outline": "#0044aa", "effect": "Temporary invulnerability for base"}
]

# Enemy types
ENEMY_RADIUS = 20
ENEMY_DAMAGE = 10
ENEMY_SPAWN_DELAY = 300
ENEMY_OUTLINE_WIDTH = 2

# Enemy Types with distinct colors and outlines:
ENEMY_TYPES = [
    {"type": "Basic", "color": "#ff6666", "outline": "#cc3333", "speed": 1.0, "health": 40},  # Red with darker outline
    {"type": "Fast", "color": "#ffff00", "outline": "#cccc00", "speed": 1.5, "health": 20},
    # Yellow with darker outline
    {"type": "Tough", "color": "#9900cc", "outline": "#660099", "speed": 0.8, "health": 80},
    # Purple with darker outline
]

BOSS_TYPE = {
    "type": "Boss", "color": "#ff0000", "outline": "#990000", "speed": 0.5, "health": 200  # Red with darker outline
}

# Difficulty settings
DIFFICULTY_SETTINGS = {
    "Easy": {"health_multiplier": 1.5, "enemy_speed_multiplier": 0.8, "enemy_count_multiplier": 0.7},
    "Medium": {"health_multiplier": 1.0, "enemy_speed_multiplier": 1.0, "enemy_count_multiplier": 1.0},
    "Hard": {"health_multiplier": 0.8, "enemy_speed_multiplier": 1.2, "enemy_count_multiplier": 1.3}
}

# High score file path
HIGH_SCORE_FILE = "highscores.json"


class HighScoreManager:
    def __init__(self):
        self.high_scores = {"Easy": 0, "Medium": 0, "Hard": 0}
        self.load_high_scores()

    def load_high_scores(self):
        try:
            if os.path.exists(HIGH_SCORE_FILE):
                with open(HIGH_SCORE_FILE, 'r') as file:
                    self.high_scores = json.load(file)
        except (json.JSONDecodeError, FileNotFoundError):
            # If the file is corrupted or doesn't exist, use default values
            self.high_scores = {"Easy": 0, "Medium": 0, "Hard": 0}

    def save_high_scores(self):
        with open(HIGH_SCORE_FILE, 'w') as file:
            json.dump(self.high_scores, file)

    def update_high_score(self, difficulty, score):
        if score > self.high_scores.get(difficulty, 0):
            self.high_scores[difficulty] = score
            self.save_high_scores()
            return True
        return False

    def get_high_score(self, difficulty):
        return self.high_scores.get(difficulty, 0)


class InfoDialog:
    def __init__(self, parent):
        self.top = tk.Toplevel(parent)
        self.top.title("Game Information")
        self.top.geometry("600x500")
        self.top.resizable(False, False)
        self.top.transient(parent)
        self.top.grab_set()

        # Create a frame with scrollbar
        frame = tk.Frame(self.top)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.text = tk.Text(frame, wrap=tk.WORD, font=('Arial', 12),
                            yscrollcommand=scrollbar.set, bg="#f0f0f0")
        self.text.pack(fill="both", expand=True)

        scrollbar.config(command=self.text.yview)

        self.add_info_text()

        close_button = tk.Button(self.top, text="Close", font=('Arial', 12),
                                 command=self.top.destroy)
        close_button.pack(pady=10)

        # Center the window on parent
        self.center_window(parent)

    def center_window(self, parent):
        self.top.update_idletasks()
        width = self.top.winfo_width()
        height = self.top.winfo_height()
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (width // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (height // 2)
        self.top.geometry(f"{width}x{height}+{x}+{y}")

    def add_info_text(self):
        # Add title and basic game info
        self.text.insert(tk.END, "BASE DEFENDER - GAME INFORMATION\n\n", "title")

        # Basic controls
        self.text.insert(tk.END, "BASIC CONTROLS:\n", "header")
        self.text.insert(tk.END, "• Move mouse to position your player around the base\n")
        self.text.insert(tk.END, "• Left-click to fire regular bullets\n")
        self.text.insert(tk.END, "• Right-click to fire special bullets (when available)\n\n")

        # Game objective
        self.text.insert(tk.END, "OBJECTIVE:\n", "header")
        self.text.insert(tk.END, "Defend your base from incoming enemies. Survive as many rounds as possible!\n\n")

        # Enemy types
        self.text.insert(tk.END, "ENEMY TYPES:\n", "header")
        self.text.insert(tk.END, "• Basic Enemy (Red): Standard enemy with balanced health and speed\n")
        self.text.insert(tk.END, "• Fast Enemy (Yellow): Moves quickly but has less health\n")
        self.text.insert(tk.END, "• Tough Enemy (Purple): Slower but has more health to defeat\n")
        self.text.insert(tk.END, "• Boss Enemy (Dark Red): Appears every 5 rounds, very tough to defeat\n\n")

        # Powerup system
        self.text.insert(tk.END, "POWERUP SYSTEM:\n", "header")
        self.text.insert(tk.END, "• Special bullets: Every 30 seconds, you receive one special bullet\n")
        self.text.insert(tk.END, "• Powerups spawn randomly every 20 seconds on the game field\n")
        self.text.insert(tk.END, "• To collect a powerup, hit it with a special bullet (right-click)\n\n")

        # Powerup types
        self.text.insert(tk.END, "POWERUP TYPES:\n", "header")
        self.text.insert(tk.END, "• Speed Boost (Green): Increases bullet speed temporarily\n")
        self.text.insert(tk.END, "• Damage Boost (Red): Increases bullet damage temporarily\n")
        self.text.insert(tk.END, "• Shield (Blue): Temporary invulnerability for your base\n\n")

        # Difficulty levels
        self.text.insert(tk.END, "DIFFICULTY LEVELS:\n", "header")
        self.text.insert(tk.END, "• Easy: More base health, slower and fewer enemies\n")
        self.text.insert(tk.END, "• Medium: Balanced difficulty\n")
        self.text.insert(tk.END, "• Hard: Less base health, faster and more enemies\n\n")

        # Scoring
        self.text.insert(tk.END, "SCORING:\n", "header")
        self.text.insert(tk.END, "• Defeat enemies to earn points\n")
        self.text.insert(tk.END, "• Try to beat your high score!\n")

        # Apply text styling
        self.text.tag_configure("title", font=('Arial', 16, 'bold'), justify='center')
        self.text.tag_configure("header", font=('Arial', 12, 'bold'))

        # Make text read-only
        self.text.config(state=tk.DISABLED)


class MainMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("Base Defender")
        self.root.resizable(False, False)

        self.high_score_manager = HighScoreManager()

        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#f0f0f0")
        self.canvas.pack()

        self.selected_difficulty = tk.StringVar(value="Medium")
        self.create_menu()

    def create_menu(self):
        # Title
        self.canvas.create_text(WIDTH // 2, HEIGHT // 4,
                                text="BASE DEFENDER",
                                font=('Arial', 48, 'bold'),
                                fill="#444444")

        # Difficulty buttons
        difficulty_frame = tk.Frame(self.canvas, bg="#f0f0f0")
        difficulty_frame_window = self.canvas.create_window(WIDTH // 2, HEIGHT // 2 - 50, window=difficulty_frame)

        easy_button = tk.Radiobutton(difficulty_frame, text="Easy", variable=self.selected_difficulty,
                                     value="Easy", font=('Arial', 16), bg="#f0f0f0",
                                     selectcolor="#d9fff2", indicatoron=0, width=10,
                                     command=self.update_high_score_display)
        medium_button = tk.Radiobutton(difficulty_frame, text="Medium", variable=self.selected_difficulty,
                                       value="Medium", font=('Arial', 16), bg="#f0f0f0",
                                       selectcolor="#d9fff2", indicatoron=0, width=10,
                                       command=self.update_high_score_display)
        hard_button = tk.Radiobutton(difficulty_frame, text="Hard", variable=self.selected_difficulty,
                                     value="Hard", font=('Arial', 16), bg="#f0f0f0",
                                     selectcolor="#d9fff2", indicatoron=0, width=10,
                                     command=self.update_high_score_display)

        easy_button.pack(pady=5)
        medium_button.pack(pady=5)
        hard_button.pack(pady=5)

        # High score display
        self.high_score_text = self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 50,
                                                       text="",
                                                       font=('Arial', 18),
                                                       fill="#444444")
        self.update_high_score_display()

        # Play button
        play_button = tk.Button(self.canvas, text="PLAY", font=('Arial', 20, 'bold'),
                                bg="#4CAF50", fg="white", width=10, height=1,
                                command=self.start_game)
        play_button_window = self.canvas.create_window(WIDTH // 2, HEIGHT * 3 // 4, window=play_button)

        # Info button
        info_button = tk.Button(self.canvas, text="INFO", font=('Arial', 14),
                                bg="#2196F3", fg="white", width=8,
                                command=self.show_info)
        info_button_window = self.canvas.create_window(WIDTH - 60, HEIGHT - 40, window=info_button)

    def update_high_score_display(self):
        difficulty = self.selected_difficulty.get()
        high_score = self.high_score_manager.get_high_score(difficulty)
        self.canvas.itemconfig(self.high_score_text, text=f"High Score ({difficulty}): {high_score}")

    def show_info(self):
        InfoDialog(self.root)

    def start_game(self):
        difficulty = self.selected_difficulty.get()
        self.canvas.delete("all")
        self.canvas.pack_forget()
        game = Game(self.root, difficulty, self.high_score_manager)


class Game:
    def __init__(self, root, difficulty="Medium", high_score_manager=None):
        self.root = root
        self.root.resizable(False, False)
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg="#f0f0f0")
        self.canvas.pack()

        self.high_score_manager = high_score_manager or HighScoreManager()
        self.difficulty = difficulty
        self.difficulty_settings = DIFFICULTY_SETTINGS[difficulty]
        self.score = 0
        self.base_health = 100 * self.difficulty_settings["health_multiplier"]
        self.round = 1
        self.mouse_pos = (WIDTH // 2, HEIGHT // 2)
        self.bullets = []
        self.enemies = []
        self.powerups = []
        self.active_powerups = []
        self.enemy_speed = 1.0
        self.enemies_to_spawn = 0
        self.wave_active = False
        self.boss_spawned = False  # Track if a boss has spawned in the wave
        self.current_high_score = self.high_score_manager.get_high_score(difficulty)

        # Special bullet tracking
        self.special_bullets_available = 1
        self.special_bullet_cooldown = 0

        # Powerup effects
        self.bullet_speed_multiplier = 1.0
        self.bullet_damage_multiplier = 1.0
        self.shield_active = False

        self.canvas.create_text(10, 10, anchor='nw', font=('Arial', 16),
                                text=f"Score: {self.score}", fill="#444", tag="score")
        self.canvas.create_text(10, 40, anchor='nw', font=('Arial', 16),
                                text=f"Base Health: {int(self.base_health)}", fill="#444", tag="health")
        self.canvas.create_text(10, 70, anchor='nw', font=('Arial', 16),
                                text=f"Round: {self.round}", fill="#444", tag="round")
        self.canvas.create_text(10, 100, anchor='nw', font=('Arial', 16),
                                text=f"Difficulty: {self.difficulty}", fill="#444")
        self.canvas.create_text(10, 130, anchor='nw', font=('Arial', 16),
                                text=f"High Score: {self.current_high_score}", fill="#444", tag="highscore")

        # Special bullets indicator
        self.special_bullets_text = self.canvas.create_text(10, 160, anchor='nw', font=('Arial', 16),
                                                            text=f"Special Bullets: {self.special_bullets_available}",
                                                            fill="#cc6600", tag="special_bullets")

        # Active powerups text
        self.powerups_text = self.canvas.create_text(10, 190, anchor='nw', font=('Arial', 16),
                                                     text="Active Powerups: None", fill="#444", tag="powerups")

        self.draw_base()
        self.player = self.canvas.create_oval(0, 0, 0, 0, fill=PLAYER_COLOR, outline=PLAYER_OUTLINE,
                                              width=PLAYER_OUTLINE_WIDTH)

        self.canvas.bind("<Motion>", self.update_mouse)
        self.canvas.bind("<Button-1>", self.shoot_regular)
        self.canvas.bind("<Button-3>", self.shoot_special)  # Right click

        # Add back to menu button
        menu_button = tk.Button(self.canvas, text="Menu", font=('Arial', 12),
                                command=self.return_to_menu)
        menu_button_window = self.canvas.create_window(WIDTH - 50, 20, window=menu_button)

        # Add info button
        info_button = tk.Button(self.canvas, text="Info", font=('Arial', 12),
                                command=self.show_info)
        info_button_window = self.canvas.create_window(WIDTH - 50, 60, window=info_button)

        # Start timers for special bullet generation and powerup spawning
        self.root.after(SPECIAL_BULLET_COOLDOWN, self.add_special_bullet)
        self.root.after(POWERUP_SPAWN_INTERVAL, self.spawn_powerup)

        self.start_round()
        self.update()

    def show_info(self):
        InfoDialog(self.root)

    def return_to_menu(self):
        self.canvas.delete("all")
        self.canvas.pack_forget()
        MainMenu(self.root)

    def draw_base(self):
        cx, cy = WIDTH // 2, HEIGHT // 2
        base_fill = BASE_COLOR

        # If shield is active, add a blue glow effect
        if self.shield_active:
            # Draw shield glow around base
            self.canvas.create_oval(
                cx - BASE_RADIUS - 10, cy - BASE_RADIUS - 10,
                cx + BASE_RADIUS + 10, cy + BASE_RADIUS + 10,
                fill="", outline="#0088ff", width=5, tag="shield"
            )

        self.canvas.create_oval(
            cx - BASE_RADIUS, cy - BASE_RADIUS,
            cx + BASE_RADIUS, cy + BASE_RADIUS,
            fill=base_fill, outline=BASE_OUTLINE, width=BASE_OUTLINE_WIDTH, tag="base"
        )

    def update_mouse(self, event):
        self.mouse_pos = (event.x, event.y)

    def add_special_bullet(self):
        self.special_bullets_available += 1
        self.canvas.itemconfig(self.special_bullets_text, text=f"Special Bullets: {self.special_bullets_available}")
        # Schedule next special bullet
        self.root.after(SPECIAL_BULLET_COOLDOWN, self.add_special_bullet)

    def shoot_regular(self, event):
        base_x, base_y = WIDTH // 2, HEIGHT // 2
        dx = self.mouse_pos[0] - base_x
        dy = self.mouse_pos[1] - base_y
        angle = math.atan2(dy, dx)
        px = base_x + ORBIT_RADIUS * math.cos(angle)
        py = base_y + ORBIT_RADIUS * math.sin(angle)

        # Apply bullet speed modifier from powerups
        bullet_speed = BULLET_SPEED * self.bullet_speed_multiplier
        vx = bullet_speed * math.cos(angle)
        vy = bullet_speed * math.sin(angle)

        bullet = {
            "id": self.canvas.create_oval(0, 0, 0, 0, fill=BULLET_COLOR, outline=BULLET_OUTLINE,
                                          width=BULLET_OUTLINE_WIDTH),
            "x": px,
            "y": py,
            "vx": vx,
            "vy": vy,
            "damage": BULLET_DAMAGE * self.bullet_damage_multiplier,
            "type": "regular"
        }
        self.bullets.append(bullet)

    def shoot_special(self, event):
        if self.special_bullets_available <= 0:
            return

        self.special_bullets_available -= 1
        self.canvas.itemconfig(self.special_bullets_text, text=f"Special Bullets: {self.special_bullets_available}")

        base_x, base_y = WIDTH // 2, HEIGHT // 2
        dx = self.mouse_pos[0] - base_x
        dy = self.mouse_pos[1] - base_y
        angle = math.atan2(dy, dx)
        px = base_x + ORBIT_RADIUS * math.cos(angle)
        py = base_y + ORBIT_RADIUS * math.sin(angle)

        # Apply bullet speed modifier from powerups
        bullet_speed = BULLET_SPEED * self.bullet_speed_multiplier
        vx = bullet_speed * math.cos(angle)
        vy = bullet_speed * math.sin(angle)

        bullet = {
            "id": self.canvas.create_oval(0, 0, 0, 0, fill=SPECIAL_BULLET_COLOR, outline=SPECIAL_BULLET_OUTLINE,
                                          width=BULLET_OUTLINE_WIDTH),
            "x": px,
            "y": py,
            "vx": vx,
            "vy": vy,
            "damage": SPECIAL_BULLET_DAMAGE * self.bullet_damage_multiplier,
            "type": "special"
        }
        self.bullets.append(bullet)

    def spawn_enemy(self):
        if self.enemies_to_spawn <= 0:
            return

        if self.round % 5 == 0 and not self.boss_spawned:  # Every 5 rounds, spawn a boss enemy
            self.spawn_boss()
            self.boss_spawned = True  # Ensure only one boss per wave
        else:
            enemy_type = random.choice(ENEMY_TYPES)
            angle = random.uniform(0, 2 * math.pi)
            distance = max(WIDTH, HEIGHT) // 2 + 100
            x = WIDTH // 2 + distance * math.cos(angle)
            y = HEIGHT // 2 + distance * math.sin(angle)

            enemy = {
                "id": self.canvas.create_oval(0, 0, 0, 0, fill=enemy_type["color"], outline=enemy_type["outline"],
                                              width=ENEMY_OUTLINE_WIDTH),
                "x": x,
                "y": y,
                "health": enemy_type["health"],
                "speed": enemy_type["speed"] * self.difficulty_settings["enemy_speed_multiplier"],
                "type": enemy_type["type"]
            }
            self.enemies.append(enemy)
            self.enemies_to_spawn -= 1

        self.root.after(ENEMY_SPAWN_DELAY, self.spawn_enemy)

    def spawn_powerup(self):
        # Randomly position the powerup on the field, but not too close to the base
        base_x, base_y = WIDTH // 2, HEIGHT // 2
        min_distance = 120  # Minimum distance from base
        max_distance = 300  # Maximum distance from base

        angle = random.uniform(0, 2 * math.pi)
        distance = random.uniform(min_distance, max_distance)
        x = base_x + distance * math.cos(angle)
        y = base_y + distance * math.sin(angle)

        # Keep powerup within screen bounds
        x = max(POWERUP_RADIUS, min(WIDTH - POWERUP_RADIUS, x))
        y = max(POWERUP_RADIUS, min(HEIGHT - POWERUP_RADIUS, y))

        # Choose a random powerup type
        powerup_type = random.choice(POWERUP_TYPES)

        powerup = {
            "id": self.canvas.create_oval(0, 0, 0, 0, fill=powerup_type["color"], outline=powerup_type["outline"],
                                          width=2),
            "x": x,
            "y": y,
            "type": powerup_type["type"]
        }

        self.powerups.append(powerup)
        self.canvas.coords(powerup["id"],
                           x - POWERUP_RADIUS, y - POWERUP_RADIUS,
                           x + POWERUP_RADIUS, y + POWERUP_RADIUS)

        # Schedule next powerup spawn
        self.root.after(POWERUP_SPAWN_INTERVAL, self.spawn_powerup)

    def spawn_boss(self):
        angle = random.uniform(0, 2 * math.pi)
        distance = max(WIDTH, HEIGHT) // 2 + 100
        x = WIDTH // 2 + distance * math.cos(angle)
        y = HEIGHT // 2 + distance * math.sin(angle)

        boss = {
            "id": self.canvas.create_oval(0, 0, 0, 0, fill=BOSS_TYPE["color"], outline=BOSS_TYPE["outline"],
                                          width=ENEMY_OUTLINE_WIDTH * 1.5),
            "x": x,
            "y": y,
            "health": BOSS_TYPE["health"],
            "speed": BOSS_TYPE["speed"] * self.difficulty_settings["enemy_speed_multiplier"],
            "type": BOSS_TYPE["type"]
        }
        self.enemies.append(boss)

        self.enemies_to_spawn -= 1

    def start_round(self):
        self.wave_active = False
        base_enemies = 3 + self.round * 2
        self.enemies_to_spawn = int(base_enemies * self.difficulty_settings["enemy_count_multiplier"])
        self.enemy_speed = 1.0 + (self.round * 0.1)
        self.boss_spawned = False  # Reset boss spawn flag
        self.spawn_enemy()
        self.canvas.itemconfig("round", text=f"Round: {self.round}")
        self.round += 1

    def apply_powerup(self, powerup_type):
        # Add the powerup to active powerups list with duration
        active_powerup = {"type": powerup_type, "time_remaining": POWERUP_DURATION}
        self.active_powerups.append(active_powerup)

        # Apply the powerup effect
        if powerup_type == "Speed":
            self.bullet_speed_multiplier = 1.5
        elif powerup_type == "Damage":
            self.bullet_damage_multiplier = 2.0
        elif powerup_type == "Shield":
            self.shield_active = True
            # Redraw base with shield
            self.canvas.delete("base")
            self.canvas.delete("shield")
            self.draw_base()

        # Update the powerups text display
        self.update_powerups_display()

    def update_powerups_display(self):
        if not self.active_powerups:
            self.canvas.itemconfig(self.powerups_text, text="Active Powerups: None")
        else:
            powerup_names = [p["type"] for p in self.active_powerups]
            self.canvas.itemconfig(self.powerups_text, text=f"Active Powerups: {', '.join(powerup_names)}")

    def update_powerups(self):
        # Process active powerups and decrease their duration
        new_active_powerups = []
        powerups_changed = False

        for powerup in self.active_powerups:
            powerup["time_remaining"] -= 16  # Decrease by frame time (16ms)

            if powerup["time_remaining"] <= 0:
                # Powerup has expired
                powerups_changed = True

                # Remove its effect
                if powerup["type"] == "Speed":
                    self.bullet_speed_multiplier = 1.0
                elif powerup["type"] == "Damage":
                    self.bullet_damage_multiplier = 1.0
                elif powerup["type"] == "Shield":
                    self.shield_active = False
                    # Redraw base without shield
                    self.canvas.delete("base")
                    self.canvas.delete("shield")
                    self.draw_base()
            else:
                new_active_powerups.append(powerup)

        if powerups_changed:
            self.active_powerups = new_active_powerups
            self.update_powerups_display()

    def update_bullets(self):
        new_bullets = []
        for bullet in self.bullets:
            bullet["x"] += bullet["vx"]
            bullet["y"] += bullet["vy"]
            x, y = bullet["x"], bullet["y"]
            self.canvas.coords(bullet["id"],
                               x - BULLET_RADIUS, y - BULLET_RADIUS,
                               x + BULLET_RADIUS, y + BULLET_RADIUS)

            # Check for collision with powerups (only special bullets can collect powerups)
            hit_powerup = None
            if bullet["type"] == "special":
                for powerup in self.powerups:
                    dist = math.hypot(bullet["x"] - powerup["x"], bullet["y"] - powerup["y"])
                    if dist < BULLET_RADIUS + POWERUP_RADIUS:
                        hit_powerup = powerup
                        self.apply_powerup(powerup["type"])
                        self.canvas.delete(powerup["id"])
                        break

            if hit_powerup:
                self.powerups.remove(hit_powerup)
                self.canvas.delete(bullet["id"])
                continue

            # Check for collision with enemies
            hit = False
            for enemy in self.enemies:
                dist = math.hypot(bullet["x"] - enemy["x"], bullet["y"] - enemy["y"])
                if dist < BULLET_RADIUS + ENEMY_RADIUS:
                    enemy["health"] -= bullet["damage"]
                    hit = True
                    break

            if not hit:
                if -BULLET_PADDING <= x <= WIDTH + BULLET_PADDING and -BULLET_PADDING <= y <= HEIGHT + BULLET_PADDING:
                    new_bullets.append(bullet)
                else:
                    self.canvas.delete(bullet["id"])
            else:
                self.canvas.delete(bullet["id"])
        self.bullets = new_bullets

    def update_enemies(self):
        new_enemies = []
        for enemy in self.enemies:
            if enemy["health"] <= 0:
                # Enemy defeated
                self.canvas.delete(enemy["id"])

                # Award points based on enemy type
                if enemy["type"] == "Boss":
                    self.score += 50
                elif enemy["type"] == "Tough":
                    self.score += 20
                elif enemy["type"] == "Fast":
                    self.score += 15
                else:  # Basic enemy
                    self.score += 10

                # Update score display
                self.canvas.itemconfig("score", text=f"Score: {self.score}")

                # Update high score if needed
                if self.score > self.current_high_score:
                    self.current_high_score = self.score
                    self.canvas.itemconfig("highscore", text=f"High Score: {self.current_high_score}")
                    self.high_score_manager.update_high_score(self.difficulty, self.score)
            else:
                # Move enemy towards base
                base_x, base_y = WIDTH // 2, HEIGHT // 2
                dx = base_x - enemy["x"]
                dy = base_y - enemy["y"]
                dist = math.hypot(dx, dy)

                # Normalize the direction and apply speed
                if dist > 0:
                    enemy["x"] += dx / dist * enemy["speed"]
                    enemy["y"] += dy / dist * enemy["speed"]

                # Update enemy position on canvas
                ex, ey = enemy["x"], enemy["y"]
                self.canvas.coords(enemy["id"],
                                   ex - ENEMY_RADIUS, ey - ENEMY_RADIUS,
                                   ex + ENEMY_RADIUS, ey + ENEMY_RADIUS)

                # Check for collision with base
                base_collision_dist = BASE_RADIUS + ENEMY_RADIUS
                if dist < base_collision_dist:
                    if self.shield_active:
                        # Shield is active, destroy the enemy and award points
                        self.canvas.delete(enemy["id"])

                        # Award points based on enemy type
                        if enemy["type"] == "Boss":
                            self.score += 50
                        elif enemy["type"] == "Tough":
                            self.score += 20
                        elif enemy["type"] == "Fast":
                            self.score += 15
                        else:  # Basic enemy
                            self.score += 10

                        # Update score display
                        self.canvas.itemconfig("score", text=f"Score: {self.score}")

                        # Update high score if needed
                        if self.score > self.current_high_score:
                            self.current_high_score = self.score
                            self.canvas.itemconfig("highscore", text=f"High Score: {self.current_high_score}")
                            self.high_score_manager.update_high_score(self.difficulty, self.score)
                    else:
                        # Shield is not active, enemy damages the base
                        self.canvas.delete(enemy["id"])

                        # Deal damage to base
                        self.base_health -= ENEMY_DAMAGE
                        if self.base_health < 0:
                            self.base_health = 0

                        # Update health display
                        self.canvas.itemconfig("health", text=f"Base Health: {int(self.base_health)}")
                else:
                    new_enemies.append(enemy)

        self.enemies = new_enemies

    def update_player(self):
        base_x, base_y = WIDTH // 2, HEIGHT // 2
        mouse_x, mouse_y = self.mouse_pos

        # Calculate angle from base to mouse
        dx = mouse_x - base_x
        dy = mouse_y - base_y
        angle = math.atan2(dy, dx)

        # Position player on the orbit
        player_x = base_x + ORBIT_RADIUS * math.cos(angle)
        player_y = base_y + ORBIT_RADIUS * math.sin(angle)

        # Update player position
        self.canvas.coords(self.player,
                           player_x - PLAYER_RADIUS, player_y - PLAYER_RADIUS,
                           player_x + PLAYER_RADIUS, player_y + PLAYER_RADIUS)

    def check_round_completion(self):
        if not self.enemies and self.enemies_to_spawn <= 0 and not self.wave_active:
            self.wave_active = True
            self.root.after(3000, self.start_round)  # 3-second delay before next round

    def check_game_over(self):
        if self.base_health <= 0:
            self.canvas.delete("all")

            # Show game over screen
            self.canvas.create_text(WIDTH // 2, HEIGHT // 3,
                                    text="GAME OVER",
                                    font=('Arial', 48, 'bold'),
                                    fill="#FF0000")

            self.canvas.create_text(WIDTH // 2, HEIGHT // 2,
                                    text=f"Final Score: {self.score}",
                                    font=('Arial', 24),
                                    fill="#444444")

            # Check if high score was achieved
            if self.score >= self.high_score_manager.get_high_score(self.difficulty):
                self.canvas.create_text(WIDTH // 2, HEIGHT // 2 + 40,
                                        text="New High Score!",
                                        font=('Arial', 24, 'bold'),
                                        fill="#4CAF50")

            # Create restart button
            restart_button = tk.Button(self.canvas, text="Play Again",
                                       font=('Arial', 20),
                                       command=self.restart_game)
            self.canvas.create_window(WIDTH // 2, HEIGHT * 2 // 3, window=restart_button)

            # Create menu button
            menu_button = tk.Button(self.canvas, text="Main Menu",
                                    font=('Arial', 20),
                                    command=self.return_to_menu)
            self.canvas.create_window(WIDTH // 2, HEIGHT * 2 // 3 + 60, window=menu_button)

            return True
        return False

    def restart_game(self):
        self.canvas.delete("all")
        self.canvas.pack_forget()
        Game(self.root, self.difficulty, self.high_score_manager)

    def update(self):
        if not self.check_game_over():
            self.update_player()
            self.update_bullets()
            self.update_enemies()
            self.update_powerups()
            self.check_round_completion()
            self.root.after(16, self.update)  # ~60 FPS


if __name__ == "__main__":
    root = tk.Tk()
    main_menu = MainMenu(root)
    root.mainloop()